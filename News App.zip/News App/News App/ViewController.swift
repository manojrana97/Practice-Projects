//
//  ViewController.swift
//  News App
//
//  Created by Manoj Kumar on 10/04/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
   
    
    @IBOutlet weak var newsTableView: UITableView!
    
    
    var url = URL(string:"https://newsapi.org/v2/top-headlines?country=in&apiKey=d21915f5676847bca504305d29369d56")

    var model = [Subjects]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        newsTableView.delegate = self
        newsTableView.dataSource = self
        
        let  dataTask = URLSession.shared.dataTask(with: url!)  { [weak self] (data, response, error) in
            if let _data = data {
                do {
                    let json = try
                        JSONSerialization.jsonObject(with: _data, options: JSONSerialization.ReadingOptions.mutableLeaves)
                    self?.parseJson(json: json)
                    
                    DispatchQueue.main.sync {
                        self?.newsTableView.reloadData()
                    }
                }catch{
                    print(error.localizedDescription)
                }
                
            }
        }
        dataTask.resume()
    }
    
    //MARK:- Function to get the parsed data into the class variables
    func parseJson(json:Any){
        guard let articleArray = json as? [String: Any] else {return}
        let articles = articleArray["articles"] as! [[String:Any]]
        for article in articles{
            let title = article["title"] as! String
            let author = article["author"] as? String
            let desc = article["description"] as? String
            let imageURL = article["urlToImage"] as? String
            
            model.append(Subjects.init(title: title, author: author ?? "", desc: desc ?? "", url:imageURL ?? ""))
        }
        
    }
    
}
//MARK:- UITableView Delegate Methods
extension ViewController:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = newsTableView.dequeueReusableCell(withIdentifier: "newsCell") as! NewsTitleCell
        cell.titelOfNews.text = model[indexPath.row].title
        cell.authorName.text = model[indexPath.row].author
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        performSegue(withIdentifier: "description", sender: indexPath.row)
        
    }

    //MARK:- Passing the Class Object to the DescriptionController
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! DescriptionController
        if let index = sender as? Int {
        vc.subjects = model [index]
        }
    }
}
