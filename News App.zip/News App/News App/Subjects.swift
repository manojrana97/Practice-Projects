//
//  Subjects.swift
//  News App
//
//  Created by Manoj Kumar on 10/04/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import Foundation

class Subjects:NSObject{
    var title:String!
    var author:String?
    var desc:String?
    var imageURL:String?
    init(title:String,author:String,desc:String,url:String) {
        self.title = title
        self.author = author
        self.desc = desc
        self.imageURL = url
    }
}
