//
//  NewsTitleCell.swift
//  News App
//
//  Created by Manoj Kumar on 10/04/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class NewsTitleCell: UITableViewCell {
    
    @IBOutlet weak var titelOfNews: UILabel!
    @IBOutlet weak var authorName: UILabel!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
