//
//  DescriptionController.swift
//  News App
//
//  Created by Manoj Kumar on 10/04/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class DescriptionController: UIViewController {
    @IBOutlet weak var descriptionView: UITextView!
    @IBOutlet weak var imageView: UIImageView!
    //MARK:- Creating an empty objects of Subjects Class
    var subjects = Subjects.init(title: "" , author: "" , desc: "" , url:"")
    var _description: String = ""
    var imageUrl:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        _description = subjects.desc ?? ""
        imageUrl = subjects.imageURL ?? ""
        descriptionView.text = "\(_description)"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Description"
        guard let url = URL(string: self.imageUrl) else { return }
        URLSession.shared.dataTask(with: url){
            (data, response, error) in
            if error != nil {
                print("Failed fetching image:", error!)
                return
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                print("error")
                return
            }
            
            DispatchQueue.main.async {
                let image = UIImage(data: data!)
                let myimageview = UIImageView(image: image)
                self.imageView.image = myimageview.image
              }
            }.resume()
        }
}
