//
//  PartyDescription.swift
//  Vehicle Insurance
//
//  Created by Manoj Kumar on 12/03/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class PartyDescription: UITableViewCell {
    
    @IBOutlet weak var partyDescriptionHeader: UILabel!
    
    @IBOutlet weak var descriptionLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
