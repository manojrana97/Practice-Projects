//
//  PolicyViewController.swift
//  Vehicle Insurance
//
//  Created by Manoj Kumar on 12/03/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class PolicyViewController: UIViewController {
    //MARK:- Button Outlets
    @IBOutlet weak var yesButton: UIButton!
    @IBOutlet weak var noButton: UIButton!
    //MARK:- View Outlets
    @IBOutlet weak var yesButtonView: UIView!
    @IBOutlet weak var noButtonView: UIView!

    @IBOutlet weak var GlassButton: UIButton!
    @IBOutlet weak var CollisionButton: UIButton!
    @IBOutlet weak var TheftButton: UIButton!
    @IBOutlet weak var weatherButton: UIButton!
    @IBOutlet weak var AnimalButton: UIButton!
    @IBOutlet weak var BreakDownButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //MARK:- Clearing Background Color clear
        yesButton.backgroundColor = UIColor.clear
        noButton.backgroundColor = UIColor.clear
        yesButtonView.layer.cornerRadius = yesButtonView.frame.width/2
        noButtonView.layer.cornerRadius = noButtonView.frame.width/2
        yesButton.layer.cornerRadius = yesButton.frame.height/2
        noButton.layer.cornerRadius = noButton.frame.height/2
        
    }
    
    
    
    //Mark:- YES NO BUTTON SELECTION METHODS
    @IBAction func yesButtonClicked(_ sender: UIButton) {
        sender.backgroundColor = UIColor.black
        noButton.backgroundColor = UIColor.clear
    }
    
    @IBAction func noButtonClicked(_ sender: UIButton) {
        sender.backgroundColor = UIColor.black
        yesButton.backgroundColor = UIColor.clear
    }
  
    @IBAction func glassButtonClicked(_ sender: UIButton) {
        sender.backgroundColor = UIColor.green
        
        CollisionButton.backgroundColor = .yellow
        TheftButton.backgroundColor = .yellow
        weatherButton.backgroundColor = .yellow
        AnimalButton.backgroundColor = .yellow
        BreakDownButton.backgroundColor = .yellow
        
    }
    
    @IBAction func collisionButtonClicked(_ sender: UIButton) {
        sender.backgroundColor = UIColor.green
        
        GlassButton.backgroundColor = .yellow
        TheftButton.backgroundColor = .yellow
        weatherButton.backgroundColor = .yellow
        AnimalButton.backgroundColor = .yellow
        BreakDownButton.backgroundColor = .yellow
    }
    
    @IBAction func theftButtonClicked(_ sender: UIButton) {
        sender.backgroundColor = UIColor.green
        
        GlassButton.backgroundColor = .yellow
        CollisionButton.backgroundColor = .yellow
        weatherButton.backgroundColor = .yellow
        AnimalButton.backgroundColor = .yellow
        BreakDownButton.backgroundColor = .yellow
    }
    
    @IBAction func weatherButtonClicked(_ sender: UIButton) {
        sender.backgroundColor = UIColor.green
        
        CollisionButton.backgroundColor = .yellow
        TheftButton.backgroundColor = .yellow
        GlassButton.backgroundColor = .yellow
        AnimalButton.backgroundColor = .yellow
        BreakDownButton.backgroundColor = .yellow
    }
    
    @IBAction func animalButtonClicked(_ sender: UIButton) {
        sender.backgroundColor = UIColor.green
       
        CollisionButton.backgroundColor = .yellow
        TheftButton.backgroundColor = .yellow
        weatherButton.backgroundColor = .yellow
        GlassButton.backgroundColor = .yellow
        BreakDownButton.backgroundColor = .yellow
    }
    
    @IBAction func breakdownButtonClicked(_ sender: UIButton) {
        sender.backgroundColor = UIColor.green

        CollisionButton.backgroundColor = .yellow
        TheftButton.backgroundColor = .yellow
        weatherButton.backgroundColor = .yellow
        AnimalButton.backgroundColor = .yellow
        GlassButton.backgroundColor = .yellow
    }
    
}
