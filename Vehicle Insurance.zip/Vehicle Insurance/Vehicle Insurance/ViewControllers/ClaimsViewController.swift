//
//  ClaimsViewController.swift
//  Vehicle Insurance
//
//  Created by Manoj Kumar on 12/03/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class ClaimsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var problemStatusTable: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    //MARK:- Table View Delegate Methods
    
    //=================================NumberOfSections========================================
    func numberOfSections(in tableView: UITableView) -> Int {
        return 9
    }
     //=================================NumberOfRowsInSection========================================
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 4{
            return 5
        }else if section == 6{
            return 4
        }else if section == 8{
            return 2
        }
        else{
            return 1
        }
    }
    //=========================CellForRowAt===============================================
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = problemStatusTable.dequeueReusableCell(withIdentifier: "headercell") as! HeaderCell
            cell.headerLabel.backgroundColor = .yellow
            cell.headerLabel.text = "GENERAL STATUS"
            return cell
        
        }else if indexPath.section == 1{
            let cell = problemStatusTable.dequeueReusableCell(withIdentifier: "lossType") as! LossTypeCell
            return cell
        }else if indexPath.section == 2{
            let cell = problemStatusTable.dequeueReusableCell(withIdentifier: "onlyLabel") as! OnlyLabelCell
            cell.statusLabel.text = "Assign Risk"
            cell.statusTypeLabel.text = "Line Of Bussiness"
            return cell
        }else if indexPath.section == 3{
            let cell = problemStatusTable.dequeueReusableCell(withIdentifier: "incidentCell") as! IncidentCell
            return cell
        }else if indexPath.section == 4{
            let cell = problemStatusTable.dequeueReusableCell(withIdentifier: "onlyLabel") as! OnlyLabelCell
            if indexPath.row == 0{
                cell.statusTypeLabel.text = "Claim Status"
                cell.statusLabel.text = "Open"
            }else if indexPath.row == 1{
                cell.statusTypeLabel.text = "Date Reported"
                cell.statusLabel.text = "11/01/16"
            }else if indexPath.row == 2{
                cell.statusTypeLabel.text = "Create Date"
                cell.statusLabel.text = "11/01/16"
            }else if indexPath.row == 3{
                cell.statusTypeLabel.text = "Coverage Type"
                cell.statusLabel.text = "Property Damage"
            }else{
                cell.statusTypeLabel.text = "Claimant"
                cell.statusLabel.text = "JPS INK DBA REMCO AGENCY"
            }
            return cell
        }
        else if indexPath.section == 5{
            let cell = problemStatusTable.dequeueReusableCell(withIdentifier: "headercell") as! HeaderCell
            cell.headerLabel.backgroundColor = .yellow
            cell.headerLabel.text = "LOSS DETAILS"
            return cell
        }else if indexPath.section == 6{
            let cell = problemStatusTable.dequeueReusableCell(withIdentifier: "onlyLabel") as! OnlyLabelCell
            if indexPath.row == 0{
                cell.statusTypeLabel.text = "Loss Date"
                cell.statusLabel.text = "11/16/2016"
            }else if indexPath.row == 1{
                cell.statusTypeLabel.text = "Notice Date"
                cell.statusLabel.text = "11/01/16"
            }else if indexPath.row == 2{
                cell.statusTypeLabel.text = "Loss Location"
                cell.statusLabel.text = "134 Street"
            }else{
                cell.statusTypeLabel.text = "Description"
                cell.statusLabel.text = "Lorem ipsum ter"
            }
            return cell
        }else if indexPath.section == 7{
            let cell = problemStatusTable.dequeueReusableCell(withIdentifier: "headercell") as! HeaderCell
            cell.headerLabel.backgroundColor = .yellow
            cell.headerLabel.text = "PARTIES INVOLVED"
            return cell
        }else{
            let cell = problemStatusTable.dequeueReusableCell(withIdentifier: "partydescription") as! PartyDescription
            if indexPath.row == 0{
                cell.partyDescriptionHeader.text = "JPS INC DBA REMKO AGENCY"
                cell.descriptionLabel.text = "Reporter, Claimant"
            }else{
                cell.partyDescriptionHeader.text = "BRONX SHEPHARDS CORP"
                cell.descriptionLabel.text = "Insured"
            }
            return cell
        }
        
        
    }
    
    
}
