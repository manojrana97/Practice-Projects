//
//  ViewController.swift
//  Vehicle Insurance
//
//  Created by Manoj Kumar on 12/03/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class WelcomeController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

