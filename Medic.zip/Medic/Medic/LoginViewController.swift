//
//  LoginViewController.swift
//  Medic
//
//  Created by Parvinderjit on 27/02/19.
//  Copyright © 2019 Zapbuild Technologies. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var logoImage: UIImageView!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var signupView: UIView!
    
    
    
    @IBOutlet weak var signupButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signupGoogleButton: UIButton!
    @IBOutlet weak var signupFacebookButton: UIButton!
    @IBOutlet weak var signupEmailButton: UIButton!
    
    
    var dataPassed: Int = 10
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        emailTextField.delegate = self
        passwordTextField.delegate = self
        
        
        signupView.isHidden = true
       
        //MARK:- SignupButton Design
        signupButton.layer.borderWidth = 1
        signupButton.layer.borderColor = UIColor.black.cgColor
        signupButton.layer.shadowOpacity = 1.0
        signupButton.layer.cornerRadius = 10
        signupButton.layer.shadowRadius = 5
        
        //MARK:- LoginButton Design
        loginButton.layer.borderWidth = 1
        loginButton.layer.borderColor = UIColor.black.cgColor
        loginButton.layer.shadowOpacity = 1.0
        loginButton.layer.cornerRadius = 10
        loginButton.layer.shadowRadius = 5
        
        //MARK:- GoogleSignup Button Design
        signupGoogleButton.layer.borderWidth = 1
        signupGoogleButton.layer.borderColor = UIColor.black.cgColor
        signupGoogleButton.layer.shadowOpacity = 1.0
        signupGoogleButton.layer.cornerRadius = 10
        signupGoogleButton.layer.shadowRadius = 5
        
        //MARK:- FacebookSignup Button Design
        signupFacebookButton.layer.borderWidth = 1
        signupFacebookButton.layer.borderColor = UIColor.black.cgColor
        signupFacebookButton.layer.shadowOpacity = 1.0
        signupFacebookButton.layer.cornerRadius = 10
        signupFacebookButton.layer.shadowRadius = 5
        
        //MARK:- EmailSignup Button Design
        signupEmailButton.layer.borderWidth = 1
        signupEmailButton.layer.borderColor = UIColor.black.cgColor
        signupEmailButton.layer.shadowOpacity = 1.0
        signupEmailButton.layer.cornerRadius = 10
        signupEmailButton.layer.shadowRadius = 5
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        emailTextField.resignFirstResponder()
        passwordTextField.resignFirstResponder()
        self.view.endEditing(true)
    }
    
    
    @IBAction func unwindToVC1(segue:UIStoryboardSegue) {
        print("I am back")
        print(dataPassed)
    }
    
    
    @IBAction func signupButtonClicked(_ sender: UIButton) {
       signupView.isHidden = false
    }
    @IBAction func LoginButtonClicked(_ sender: UIButton) {
        if emailTextField.text == "manoj" && passwordTextField.text == "1234"{
            navigateToHomeScreen()
        }else{
            signupView.isHidden = true
        }
        
        
    }
    private func navigateToHomeScreen(){
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "navigation") as! NavigationController
        self.present(newViewController, animated: true, completion: nil)
    

    }

}
