//
//  SignupViewController.swift
//  Medic
//
//  Created by Parvinderjit on 27/02/19.
//  Copyright © 2019 Zapbuild Technologies. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {
    @IBOutlet weak var firstnameLabel: UILabel!
    
    @IBOutlet weak var lastnameLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var retypePasswordLabel: UILabel!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
     
    }
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: nil)
        if let vc  = segue.destination as? LoginViewController {
                                                                    //testing a value
        }
    }
    
  
    @IBAction func backButtonTapped(_ sender: Any) {
        performSegue(withIdentifier: "goBack", sender: nil)
    }
    

    

  

}





















