//
//  ViewController.swift
//  Medic
//
//  Created by Manoj Rana on 25/02/19.
//  Copyright © 2019 Zapbuild Technologies. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var Availability: UILabel!
//MARK:- Button Outlets
    @IBOutlet weak var profileButton: UIButton!
    @IBOutlet weak var prescriptionButton: UIButton!
    @IBOutlet weak var ordersButton: UIButton!
    @IBOutlet weak var contactButton: UIButton!
    @IBOutlet weak var settingButton: UIButton!
    @IBOutlet weak var logoutButton: UIButton!
    

    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK:- ProfileButton Design
          profileButton.layer.borderWidth = 1
          profileButton.layer.borderColor = UIColor.black.cgColor
          profileButton.layer.shadowOpacity = 1.0
        
        //MARK:- PrescriptionButton Design
          prescriptionButton.layer.borderWidth = 1
          prescriptionButton.layer.borderColor = UIColor.black.cgColor
          prescriptionButton.layer.shadowOpacity = 1.0
        
        //MARK:- OrdersButton Design
          ordersButton.layer.borderWidth = 1
          ordersButton.layer.borderColor = UIColor.black.cgColor
          ordersButton.layer.shadowOpacity = 1.0
        
        //MARK:- ContactButton Design
          contactButton.layer.borderWidth = 1
          contactButton.layer.borderColor = UIColor.black.cgColor
          contactButton.layer.shadowOpacity = 1.0
        
        //MARK:- SettingsButton Design
          settingButton.layer.borderWidth = 1
          settingButton.layer.borderColor = UIColor.black.cgColor
          settingButton.layer.shadowOpacity = 1.0
        
        //MARK:- LogoutButton Design
          logoutButton.layer.borderWidth = 1
          logoutButton.layer.borderColor = UIColor.black.cgColor
          logoutButton.layer.shadowOpacity = 1.0
    }
    
    
    @IBAction func SwitchValueChanged(_ sender: UISwitch) {
        if sender.isOn == true{
            Availability.text = "Available"
        }else{
            Availability.text = "Not Available"
        }
    }
    
    
    //MARK:- Button Methods
    @IBAction func myProfileClicked(_ sender: UIButton) {
        print("My Profile Clicked")
    }
    
    @IBAction func myPrescriptionClicked(_ sender: UIButton) {
        print("My Prescription Clicked")

    }
    @IBAction func myOrdersClicked(_ sender: UIButton) {
        print("My Orders Clicked")

    }
    @IBAction func contactUsClicked(_ sender: UIButton) {
        print("Contact us  Clicked")

    }
    @IBAction func settingsClicked(_ sender: UIButton) {
        print("Settings Clicked")

    }
    @IBAction func logoutClicked(_ sender: UIButton) {
        navigateToLoginScreen()
        print("logout Clicked")

    }
    private func navigateToLoginScreen(){
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "Login") as! LoginViewController
        self.present(newViewController, animated: true, completion: nil)
        
        
    }
    
    
    
    


}

