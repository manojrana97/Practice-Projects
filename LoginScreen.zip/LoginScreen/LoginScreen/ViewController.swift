//
//  ViewController.swift
//  LoginScreen
//
//  Created by Parvinderjit on 13/02/19.
//  Copyright © 2019 Parvinderjit. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var emailId: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var rePassword: UITextField!
    @IBOutlet weak var signupButton: UIButton!
    @IBOutlet weak var logoImage: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstName.delegate = self
        lastName.delegate = self
        emailId.delegate = self
        password.delegate = self
        rePassword.delegate = self
        signupButton.isEnabled = false
    }
    override func viewDidLayoutSubviews() {
        logoImage.layer.cornerRadius = (logoImage.frame.height)/2
    }
    
    
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == firstName {
            
            let fname = (firstName.text! as NSString).replacingCharacters(in: range, with: string)
            
            if !fname.isEmpty {
                signupButton.isEnabled = false
            }
            else{
                signupButton.isEnabled = false
            }
            signupButton.isEnabled = false
            
        }
        if textField == lastName {
            
            let lname = (lastName.text! as NSString).replacingCharacters(in: range, with: string)
            
            if !lname.isEmpty && lname.count > 2 && lname.count < 20 {
                signupButton.isEnabled = true
            }else{
                signupButton.isEnabled = false
            }
                  }
        if textField == emailId {
            let email = (emailId.text! as NSString).replacingCharacters(in: range, with: string)
            
            if !email.isEmpty && email.count > 2 && email.count < 20 && email.contains("@") {
                signupButton.isEnabled = true
                
            }else{
                signupButton.isEnabled = false
                
            }
           
            
        }
        if textField == password {
            let pass = (password.text! as NSString).replacingCharacters(in: range, with: string)
            
            if !pass.isEmpty && pass.count > 2 && pass.count < 20 {
                signupButton.isEnabled = true
                
            }else{
                signupButton.isEnabled = false
            }
        }
        if textField == rePassword {
            let repass = (rePassword.text! as NSString).replacingCharacters(in: range, with: string)
            
            if !repass.isEmpty && repass.count > 2 && repass.count < 20 {
                signupButton.isEnabled = true
                
            }else{
                signupButton.isEnabled = false
            }
        }
        
        return true
    }
    
    
    
    
    
    
    @IBOutlet weak var maleButton: UIButton!
    @IBOutlet weak var femaleButton: UIButton!
    
    
    @IBAction func maleSelected(_ sender: UIButton) {
        maleButton.backgroundColor = UIColor.yellow
        femaleButton.backgroundColor = UIColor.magenta
        
    }
    @IBAction func femaleSelected(_ sender: UIButton) {
        femaleButton.backgroundColor = UIColor.yellow
        maleButton.backgroundColor = UIColor.magenta
    }
    
    
    
    
//    func checkName()->Bool{
//        if firstName.text!.count > 2 && firstName.text!.count < 8{
//            return true
//        }
//        
//    }
    
    
    
    
    
}

