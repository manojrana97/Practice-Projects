//
//  ViewController.swift
//  JsonDemo
//
//  Created by Manoj Kumar on 10/04/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //MARK:- Outlets and Variables
    @IBOutlet weak var loader: UIActivityIndicatorView!
    @IBOutlet weak var tbView: UITableView!
    var url = URL(string:"https://jsonplaceholder.typicode.com/users")
    
    struct user {
                var name:String!
                var username:String!
                var phone:String!
    }
    
    var model:[user] = [user]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tbView.delegate = self
        tbView.dataSource = self
        
        
        let  dataTask = URLSession.shared.dataTask(with: url!)  { [weak self] (data, response, error) in
            if let _data = data {
                do {
                    let json = try
                        JSONSerialization.jsonObject(with: _data, options: JSONSerialization.ReadingOptions.mutableLeaves)
                    self?.parseJson(json: json)
                    
                    DispatchQueue.main.sync {
                        self?.tbView.reloadData()
                        self?.loader.isHidden = true
                    }
                }catch{
                    print(error.localizedDescription)
                }
                
            }
        }
        
        dataTask.resume()
        
    }
    
    func parseJson(json:Any){
        guard let dataArray = json as? [[String: Any]] else {return}
        
        for dictArray in dataArray{
            let name = dictArray["name"] as! String
            let username = dictArray["username"] as! String
            let phone = dictArray["phone"] as! String
            model.append(user(name: name, username: username, phone: phone))
            
        }
        print(model)
    }
}


//MARK:- TableView Delegate Methods
extension ViewController:UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tbView.dequeueReusableCell(withIdentifier: "UserTableViewCell") as! UserTableViewCell
        cell.nameLabel.text = model[indexPath.row].name
        cell.userId.text = model[indexPath.row].username
        cell.phoneNumber.text = model[indexPath.row].phone
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
