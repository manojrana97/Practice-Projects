//
//  SecondViewController.swift
//  DataPassTo&Fro
//
//  Created by Parvinderjit on 21/02/19.
//  Copyright © 2019 Zapbuild Technologies. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var receiverName: UITextView!
    @IBOutlet weak var receiverDescription: UITextView!
    @IBOutlet weak var receiverAge: UITextView!
    var name:String?
    var desc:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        receiverName.text = name
        receiverDescription.text = desc
    }
    
    
    //MARK:- DataPassing Back Method
    @IBAction func sendBackClicked(_ sender: UIButton) {
        if let controllers = self.navigationController?.viewControllers{
            for controller in controllers{
                if let firstController = controller as? FirstViewController {
                    firstController.senderName.text = "\(receiverName.text!)"
                    firstController.senderDescription.text = "\(receiverDescription.text!)"
                    firstController.senderAge.text = "\(receiverAge.text!)"
                    self.navigationController?.popToViewController(firstController, animated: true)
                    break
                }
            }
        }
        
        
        
    }
    
   
   
}
