//
//  ViewController.swift
//  DataPassTo&Fro
//
//  Created by Parvinderjit on 21/02/19.
//  Copyright © 2019 Zapbuild Technologies. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    @IBOutlet weak var senderName: UITextView!
    @IBOutlet weak var senderDescription: UITextView!
    @IBOutlet weak var senderAge: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    //MARK:- Datapassing Forword Method
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if let vc = segue.destination as? SecondViewController{
            vc.name = senderName.text
            vc.desc = senderDescription.text
        }
    }
   
}

