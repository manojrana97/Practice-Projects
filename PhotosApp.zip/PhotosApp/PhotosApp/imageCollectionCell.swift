//
//  imageCollectionCell.swift
//  PhotosApp
//
//  Created by Manoj Kumar on 14/03/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class imageCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var PictureView: UIImageView!
}
