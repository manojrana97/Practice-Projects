//
//  SectionViewController.swift
//  PhotosApp
//
//  Created by Manoj Kumar on 14/03/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class SectionViewController: UIViewController,UICollectionViewDelegate {

    
    //MARK:- Outlets and Variables
    @IBOutlet weak var imageCollectionForSection: UICollectionView!
    @IBOutlet weak var imageViewSegment: UISegmentedControl!
    var imagesInARow = 1
    var images:[UIImage] = []
    var controllerTitle:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = controllerTitle
    }
    
    //MARK:- CollectionView delegate Methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let imageVC = storyboard?.instantiateViewController(withIdentifier: "ShowImageViewController") as! ShowImageViewController
        imageVC.viewImage = images[indexPath.row]
        self.navigationController?.pushViewController(imageVC, animated: true)
    }
    
    @IBAction func segmentClicked(_ sender: UISegmentedControl) {
        imagesInARow = {switch imageViewSegment.selectedSegmentIndex{
        case 0:
            return 1
        case 1:
            return 2
        case 2:
            return 3
        case 3:
            return 4
        default:
            return 1
            }
            
        }()
        imageCollectionForSection.reloadData()
    }
   
    
    
    
    
}
//MARK:- CollectionViewDatasource Methods
extension SectionViewController:UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = imageCollectionForSection.dequeueReusableCell(withReuseIdentifier: "sectionViewCell", for: indexPath) as! SectionViewCell
        cell.pictureView.image = images[indexPath.row]
        return cell
    }
}
//MARK:- CollectionView DelegateFlowlayout Methods
extension SectionViewController:UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width:imageCollectionForSection.frame.width/CGFloat(imagesInARow), height: 200)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat
    {
        
        return 0;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat
    {
        
        return 0;
    }
}
