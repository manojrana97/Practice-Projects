//
//  ShowImageViewController.swift
//  PhotosApp
//
//  Created by Manoj Kumar on 14/03/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class ShowImageViewController: UIViewController,UIScrollViewDelegate {
    @IBOutlet weak var imageZoomer: UIScrollView!
    @IBOutlet weak var imageView: UIImageView!
    var viewImage:UIImage = UIImage()
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = viewImage
        imageZoomer.minimumZoomScale = 1.0
        imageZoomer.maximumZoomScale = 6.0

    }
    
    //MARK:- Zooming Images Using ScrollViewDelegate
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }

}
