//
//  ViewController.swift
//  PhotosApp
//
//  Created by Manoj Kumar on 14/03/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate{
   
    //MARK:- Outlets and variables
    var imagesForOne:[UIImage] = [#imageLiteral(resourceName: "4"),#imageLiteral(resourceName: "2"),#imageLiteral(resourceName: "10"),#imageLiteral(resourceName: "9"),#imageLiteral(resourceName: "7"),#imageLiteral(resourceName: "16"),#imageLiteral(resourceName: "14"),#imageLiteral(resourceName: "1"),#imageLiteral(resourceName: "15"),#imageLiteral(resourceName: "4"),#imageLiteral(resourceName: "11"),#imageLiteral(resourceName: "4")]
    var imagesForTwo:[UIImage] = [#imageLiteral(resourceName: "1"),#imageLiteral(resourceName: "15"),#imageLiteral(resourceName: "4"),#imageLiteral(resourceName: "11"),#imageLiteral(resourceName: "4")]
    var images:[[UIImage]]! = []
    var months:[String] = ["January","February"]
    
    @IBOutlet weak var imageCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        images=[imagesForOne,imagesForTwo]
    }
    
    //MARK:- CollectionView Delegate Methods
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return months.count
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
      return images[section].count
    }
    
    

    @objc func nextButtonClicked(sender:UIButton){
       
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let sectionVC = storyboard.instantiateViewController(withIdentifier: "SectionViewController") as! SectionViewController
            sectionVC.images = images[sender.tag]
            sectionVC.controllerTitle = months[sender.tag]
            self.navigationController?.pushViewController(sectionVC, animated: true)
        
    }
    
    
    
   

}

//MARK:- CollectionView DataSource Methods
extension ViewController:UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        
        
        
        let headerView = collectionView.dequeueReusableSupplementaryView(
            ofKind: kind,
            withReuseIdentifier: "sectionHeader",
            for: indexPath) as? HeaderCollectionView
        headerView?.sectionHeaderLabel.text = months[indexPath.section]
        
        headerView?.gotoSectionButton.tag = indexPath.section
        headerView?.gotoSectionButton.addTarget(self, action: #selector(nextButtonClicked(sender:)), for: .touchUpInside)
        return headerView!
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = imageCollectionView.dequeueReusableCell(withReuseIdentifier: "imageCollectionCell", for: indexPath) as! imageCollectionCell
        cell.PictureView.image = images[indexPath.section][indexPath.row]
        return cell
    }
}




//MARK:- CollectionView Delegate method for giving Spacing and Size
extension ViewController:UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat
    {
        
        return 5;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat
    {
        
        return 5;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 30, height: 30)
    }
}
