//
//  SectionViewCell.swift
//  PhotosApp
//
//  Created by Manoj Kumar on 14/03/19.
//  Copyright © 2019 Manoj Kumar. All rights reserved.
//

import UIKit

class SectionViewCell: UICollectionViewCell {
    @IBOutlet weak var pictureView: UIImageView!
    
}
