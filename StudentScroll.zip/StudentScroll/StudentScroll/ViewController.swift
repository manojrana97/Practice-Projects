

import UIKit

class ViewController: UIViewController,UIScrollViewDelegate {
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var scrollProgress: UIProgressView!
    
    //MARK:- StudentDeatails Array
    var names:[String] = ["Manoj","Danish","Aman","Parvesh","Samar Bahadur","Umang","Hina","Ashok","Alok","Ajay"]
    var roll:[String] = ["101","102","103","104","105","106","107","108","109","110"]
    var dept:[String] = ["iOs","Android","Java","C","ROR","Bootstrap","Web Development","UX Design","Python","C++"]
    //MARK:- position variables for scrollView
    let studentViewWidth:CGFloat = 275
    let studentViewHeight:CGFloat = 90
    var yposition:CGFloat = 0
    var xposition:CGFloat = 50
    var scrollViewContentSize:CGFloat = 0
    
    //MARK:- Didload Method
    override func viewDidLoad() {
        super.viewDidLoad()
        for index in 0..<names.count{
            //MARK:- Creating a Custom View
            let studentView = UIView()
            studentView.frame.size.width = studentViewWidth
            studentView.frame.size.height = studentViewHeight
            studentView.frame.origin.y = yposition
            studentView.frame.origin.x = xposition
            //studentView.backgroundColor = UIColor.cyan
            
            //MARK:- Creating custom labels
            let nameLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 275, height: 30))
            let rollnoLabel = UILabel(frame: CGRect(x: 0, y: 30, width: 275, height: 30))
            let deptLabel = UILabel(frame: CGRect(x: 0, y: 60, width: 275, height: 30))
            
            //MARK:- Adding Color to Labels
            nameLabel.backgroundColor = UIColor.yellow
            rollnoLabel.backgroundColor = UIColor.green
            deptLabel.backgroundColor = UIColor.gray
           
            //MARK:- Adding Values to labels
            nameLabel.text = names[index]
            rollnoLabel.text = roll[index]
            deptLabel.text = dept[index]
           
            nameLabel.textAlignment = .center
            rollnoLabel.textAlignment = .center
            deptLabel.textAlignment = .center
            
            //MARK:- Adding Labels to customView
            studentView.addSubview(nameLabel)
            studentView.addSubview(rollnoLabel)
            studentView.addSubview(deptLabel)
            
            //MARK:- Adding the customView to scrollView
            scrollView.addSubview(studentView)
            
            let spaceValue:CGFloat = 10
            yposition += studentViewHeight + spaceValue
            scrollViewContentSize += studentViewHeight + spaceValue
            scrollView.contentSize = CGSize(width: studentViewWidth, height: scrollViewContentSize)
            
        }
        
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        scrollProgress.progress = Float(scrollView.contentOffset.y / 428.0)
    }
    
    
    
    //MARK:- Display Switch method
    @IBAction func swichClicked(_ sender: UISwitch) {
        if sender.isOn{
           scrollView.isHidden = false
        }
        else{
            scrollView.isHidden = true
        }
    }
    
}



















